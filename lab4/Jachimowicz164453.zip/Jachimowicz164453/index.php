<html>
<head>
	<meta http-equiv="Content-type" content="text/html ;  charset=UTF-8"/>
	<meta http-equiv="Content-Language" content="pl"/>
	<meta name="Author" content="Szymon Jachimowicz"/>
	<link rel="stylesheet" href="css/stylesheet.css">
	<title>Historia lotów kosmicznych</title>
</head>
<body>
	<table>
		<tr>
			<td width=17%>
				<a href="index.php"><h1>Strona główna</h1></a>
			</td>
			<td width=15%>
				<a href="html/galeria.html"><h1>Galeria</h1></a>
			</td>
			<td width=12%>
				<a href="html/historia.html"><h1>Historia</h1></a>
			</td >
			<td width=12%>
				<a href="html/lot.html"><h1>Komercyjny lot kosmiczny</h1></a>
			</td>
			<td width=10%>
				<a href="html/kontakt.html"><h1>Kontakt</h1></a>
			</td>
			<td width=10%>
				<a href="html/java.html"><h1>Java</h1></a>
			</td>
			<td width=10%>
				<a href="html/jquery.html"><h1>Jquery</h1></a>
			</td>
			<td width=10%>
				<a href="php/164453_ISI2.php"><h1>pHp</h1></a>
			</td>
		</tr>
	</table>
	
	<br><br>

	<img src="img/banner.jpg" style="width:100%"/>
	
	<center>
		<p id='mainfont'>Witajcie ziemianie!</p>
	
		<p id='mainfont2'>Jesteśmy grupa fanatyków przestrzeni kosmicznej, intersuje nas jak powstał wszechświat, co się w nim dzieje i na bierząco śledzimy najnowsze odkrycia. Kosmos jest dla nas wciąż nieznany, nie zbadaliśmy dokładnie całego kosmosu, nie wiemy dokładnie jakie procesy w nim zachodzą.
		Na przykład nie potrafimy wytłumaczyć czym jest czarna materia, a to właś nie z niej w 98% składa się kosmos. Człowiek od dawna próbował zbadać nieskończoną przestrzeń nad naszymi głowami, chcieli zrozumieć na co patrzą w nocy i czym są te jasne punkty na niebie.
		W XX wieku odbywa się pierwszy lot, pierwsza misja mająca na celu zbadanie kosmosu i poznanie jego tajemnic. Chcielibyśmy przedstawić najważniejsze loty załogowe i bezzałogowe w kosmos, które pozwoliły poznać nam i lepiej zrozumieć to co nas otacza.</p>
	</center>
	
	<br><br>
	
	<?php
		 $nr_indeksu='164453';
         $nrGrupy='2';
         echo 'Jachimowicz Szymon: '.$nr_indeksu.' grupa: '.$nrGrupy.'<br/><br/>';
	?>
</body>
</html>